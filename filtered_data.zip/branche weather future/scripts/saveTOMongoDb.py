from pymongo import MongoClient
from config import MONGO_URI_Theo, MONGO_DATABASE, MONGO_COLLECTION

from get_future_weather_date import fetch_weather_data, get_key_weather_data

def save_to_mongodb(data, mongo_uri, database_name, collection_name):
    try:
        client = MongoClient(mongo_uri)
        db = client[database_name]
        collection = db[collection_name]
        collection.insert_many(data)
        print(f"Data saved successfully to MongoDB in database '{database_name}', collection '{collection_name}'.\n")
    except Exception as e:
        print(f"Error while saving to MongoDB: {e}")
    finally:
        client.close()

def main():
    key_data,_  = get_key_weather_data(fetch_weather_data())  
    if key_data:
        save_to_mongodb(key_data, MONGO_URI_Theo,MONGO_DATABASE, MONGO_COLLECTION)

if __name__ == "__main__":
    main()