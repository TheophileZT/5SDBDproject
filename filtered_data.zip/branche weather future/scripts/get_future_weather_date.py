import requests
import json
import csv

from config import LAT, LON, WEATHER_API_BASE_URL, WEATHER_API_KEY

# Paramètres de la requête
params = {
    'lat':LAT,
    'lon':LON,
    'appid': WEATHER_API_KEY,  # Clé API
}
#fetch data de future weather en envoyant une requête GET à l'API
def fetch_weather_data():
    try:
        response = requests.get(WEATHER_API_BASE_URL, params=params)
        if response.status_code == 200:
            allData = response.json()  
            return allData
        else:
            print(f"Erreur {response.status_code}: {response.text}")
    except Exception as e:
        print(f"Une erreur est survenue : {e}")


def get_key_weather_data(data):
    city_name = data['city']['name']
    country = data['city']['country']
    city_info = f"{city_name}, {country}" 
    print("-" * 50)
   
    key_data = []
    for forecast in data['list']:
         key_data.append({
            "datetime": forecast['dt_txt'],
            "temperature": forecast['main']['temp'],
            "humidity": forecast['main']['humidity'],
            "description": forecast['weather'][0]['description'],
            "wind_speed": forecast['wind']['speed']
        })
    return key_data,city_info

def print_key_data(city_info, key_data):
    print(f"Prévisions météo pour {city_info}:")
    print("-" * 50)
    for forecast in key_data:
        print(f"Date/Heure: {forecast['datetime']}")
        print(f"Température: {forecast['temperature']}°C")
        print(f"Humidité: {forecast['humidity']}%")
        print(f"Description: {forecast['description']}")
        print(f"Vitesse du vent: {forecast['wind_speed']} m/s")
        print("-" * 50)
 
def save_to_json(data, filename="weather_data.json"):
    try:
        with open(filename, 'w') as json_file:
            json.dump(data, json_file, indent=4)  # Save data in JSON format with indentation
        print(f"Weather data has been saved to {filename}.")
    except Exception as e:
        print(f"An error occurred while saving to JSON: {e}")


def save_to_csv(key_data, filename="weather_data.csv"):
    try:
        with open(filename, mode='w', newline='') as csv_file:
            writer = csv.writer(csv_file)
            # Write the header row
            writer.writerow(["Date/Time", "Temperature (°C)", "Humidity (%)", "Description", "Wind Speed (m/s)"])
            # Write each row of key data
            for item in key_data:
                writer.writerow([
                    item["datetime"],
                    item["temperature"],
                    item["humidity"],
                    item["description"],
                    item["wind_speed"]
                ])
        print(f"Key weather data has been saved to {filename}.")
    except Exception as e:
        print(f"An error occurred while saving to CSV: {e}")


allData=fetch_weather_data()
key_data,city_info = get_key_weather_data(allData)  
print_key_data(city_info,key_data)
save_to_json(key_data)  
save_to_csv(key_data) 
