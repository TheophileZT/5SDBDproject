# Configuration de l'API OpenWeatherMap
WEATHER_API_KEY = "ad8f9db26c6726c4f963aaa047fbf875"
WEATHER_API_BASE_URL = "http://api.openweathermap.org/data/2.5/forecast"
LAT = 43.6  # Latitude
LON = 1.44  # Longitude

# Configuration de MongoDB
MONGO_URI_Theo = "mongodb+srv://theozt25:MGZ7Osyw7gMrGU4O@integratorproject.5ulkz.mongodb.net/?retryWrites=true&w=majority&appName=IntegratorProject"
MONGO_URI_Yongjia = "mongodb+srv://zeng:zengyongjia@cluster0.qvuo4.mongodb.net/"
MONGO_DATABASE = "DB"
MONGO_COLLECTION = "FutureWeather"